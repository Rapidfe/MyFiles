int mat_mul(int**, int**, int**, int);
int mat_mul_th(int**, int**, int**, int);
